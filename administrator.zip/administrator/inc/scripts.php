<!-- JavaScript -->
<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.maskedinput.min.js"></script>
<script src="js/functions.js"></script>
<script src="js/scripts.js"></script>