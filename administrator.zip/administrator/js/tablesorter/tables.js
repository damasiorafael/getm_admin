$(function() {
  $("table").tablesorter({debug: false});
});
